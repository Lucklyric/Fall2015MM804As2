# Fall2015MM804As2
Fall2015MM804As2
Name: (Alvin)Xinyao Sun
CSID: 1251167
--------------------------------------
Programs-/
	-/camera_posted #Question 1
	-/objects_posted #Question 2
	-/scene_posted #Question 3
	-/scene_posted #needed scene files
--------------------------------------
The program is modified based on the Professor's given code with needed implementations based on the assignment's requirements.
To run each program, open each solutions files inside each folder, and make sure the path of needed libraries and header folder of Freeglut and FreeImage have been added to the project's property.
Running through the debug mode in Visual Studio 2015 you can use 1.txt and 2.txt to test the two given test scenes. 
If you have any questions please send email to xinyao1@ualberta.ca