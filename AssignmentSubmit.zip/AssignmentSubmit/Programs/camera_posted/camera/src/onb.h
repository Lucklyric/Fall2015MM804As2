//
// Author: Herb Yang, March 9, 2010
//
#ifndef ONB_H
#define ONB_H
#include "vector3.h"
class ONB {
public:
    Vector3 u,v,w;
};
#endif
